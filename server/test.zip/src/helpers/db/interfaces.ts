export interface IDbItem {
  name: string
  buyPrice: number
  sellPrice: number
}